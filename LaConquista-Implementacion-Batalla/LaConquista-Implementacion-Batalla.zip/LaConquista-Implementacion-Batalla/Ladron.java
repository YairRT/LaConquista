public class Ladron extends Villano{

	public Ladron(String nombre, int experiencia, int puntosDefensa, int hP, int ataque, String nombreAtaque){
		super(nombre, experiencia, puntosDefensa, nombreAtaque);
	}
}
