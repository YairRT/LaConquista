public class Esbirro extends Villano{

	public Esbirro(String nombre, int experiencia, int puntosDefensa, int hP, int ataque, String nombreAtaque){
		super(nombre, experiencia, puntosDefensa, nombreAtaque);
	}
}
