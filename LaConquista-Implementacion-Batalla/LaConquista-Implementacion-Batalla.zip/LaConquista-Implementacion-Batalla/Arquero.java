public class Arquero extends Villano{

	public Arquero(String nombre, int experiencia, int puntosDefensa, int hP, int ataque, String nombreAtaque){
		super(nombre, experiencia, puntosDefensa, nombreAtaque);
	}
}
