public class Sacerdote extends PersonajePrincipal{
	public Sacerdote(String nombre, int experiencia, int puntosDefensa, int hP, int ataque){
		super(nombre);
	}
}
