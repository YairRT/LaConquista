import javafx.application.Application;
import javafx.scene.layout.*;
import javafx.scene.*;
import javafx.stage.*;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.event.*;
public class Battle extends Scene{
	private Main main;
	public Battle(Main main, PersonajePrincipal heroe, Villano enemigo){
		super(new BorderPane());
		this.main = main;
		BorderPane bp = (Borderpane)super;
		Label lb1 = new Label(heroe.getNombre());
		Label lb2 = new Label(enemigo.getNombre());
		gp.setLeft(lb1);
		gp.setRight(lb2);
		
		//Se crean los botones para poder atacar al adversario
		Button normalAttack = new Button("Ataque normal");
		
	}
}