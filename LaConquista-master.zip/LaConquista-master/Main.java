import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.control.Label;
import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;
import javafx.collections.ObservableList;

public class Main extends Application{
  private PersonajePrincipal heroe;
  private static int[][] arregloMapa;
  private static Mapa mapaPrincipal;
  private Stage primaryStage;
  public static void main(String[] args) { 
    launch(args);
  }

  public void start(Stage primaryStage){
	this.primaryStage = primaryStage;
	primaryStage.setScene(new CharacterSelection(this));
	primaryStage.show();
  }
  
  

	public void openGame(){
		/*PersonajePrincipal diego = new PersonajePrincipal("Dieguapo",0,0,0,0);
		Villano pedrito = new Villano("Pedriro", 10, 5, 0,0,"sandwich");
		diego.adquirirExperiencia(20);*/
		//comenzarPelea(diego, pedrito);
		mapaPrincipal = new Mapa(12, 5, heroe);
		System.out.println(heroe.getNombre());
		mapaPrincipal.imprimirPlano();
		arregloMapa = mapaPrincipal.getPlano();
		mapaPrincipal.start(primaryStage);
		
	}
	
	public void setPersonajePrincipal(PersonajePrincipal heroe){
	this.heroe = heroe;
	}
}