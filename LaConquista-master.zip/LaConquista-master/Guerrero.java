public class Guerrero extends PersonajePrincipal{
	public Guerrero(String nombre, int experiencia, int puntosDefensa, int hP, int ataque){
		super(nombre, experiencia, puntosDefensa, hP, ataque);
	}
}