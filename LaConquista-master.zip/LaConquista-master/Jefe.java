public class Jefe extends Villano{
	
	public Jefe(String nombre, int experiencia, int puntosDefensa, int hP, int ataque, String nombreAtaque){
		super(nombre, experiencia, puntosDefensa, hP, ataque, nombreAtaque);
	}
}