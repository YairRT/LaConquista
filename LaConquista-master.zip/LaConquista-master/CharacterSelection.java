import javafx.application.Application;
import javafx.scene.layout.*;
import javafx.scene.*;
import javafx.stage.*;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.event.*;
import javafx.geometry.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.StageStyle;
import javafx.scene.paint.Color;
public class CharacterSelection extends Scene{
	private Main main;
	public CharacterSelection(Main main){
		super(new GridPane());
		this.main = main;
		
		GridPane gp = (GridPane)super.getRoot();
		Button warriorButton = new Button();
		Button tlatoaniButton = new Button();
		Button priestButton = new Button();
		
		
		warriorButton.setStyle("-fx-background-image:url('C:/Users/hp/Documents/Tec/Computing/Images/warrior.png');");
		warriorButton.setMinHeight(500);
		warriorButton.setMinWidth(200);
		warriorButton.addEventHandler(MouseEvent.MOUSE_CLICKED,new EventHandler<MouseEvent>(){
			public void handle(MouseEvent e){
				PersonajePrincipal warrior = new Guerrero("warrior",10,10,10,10);
				main.setPersonajePrincipal(warrior);
				main.openGame();
			}
		});
		
		tlatoaniButton.setStyle("-fx-background-image:url('C:/Users/hp/Documents/Tec/Computing/Images/Tlatoani.png');");
		tlatoaniButton.setMinHeight(500);
		tlatoaniButton.setMinWidth(200);
		tlatoaniButton.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>(){
			public void handle(MouseEvent e){
				PersonajePrincipal tlatoani = new Tlatoani("Tlatoani",10,10,10,10);
				main.setPersonajePrincipal(tlatoani);
				main.openGame();
			}
		});
		
		priestButton.setStyle("-fx-background-image:url(´C:/Users/hp/Documents/Tec/Computing/Images/Priest.png);");
		priestButton.setMinHeight(500);
		priestButton.setMinWidth(200);
		priestButton.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler<MouseEvent>(){
		public void handle(MouseEvent e){
			PersonajePrincipal priest = new Sacerdote("Sacerdote",10,10,10,10);
			main.setPersonajePrincipal(priest);
			main.openGame();
		}	
		});
		
		gp.add(warriorButton,0,0);
		gp.add(tlatoaniButton,1,0);
		gp.add(priestButton,2,0);
		
	}
}